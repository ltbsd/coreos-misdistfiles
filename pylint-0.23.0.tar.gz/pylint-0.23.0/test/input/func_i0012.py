# pylint:enable=W0404
"""check warning on local enabling
"""
__revision__ = 1

