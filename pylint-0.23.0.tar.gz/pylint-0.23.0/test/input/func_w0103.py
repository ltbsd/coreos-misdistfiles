"""test max branch 
"""

__revision__ = ''

def stupid_function(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9):
    """reallly stupid function"""
    print arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9
